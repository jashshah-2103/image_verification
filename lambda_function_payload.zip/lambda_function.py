import json
import boto3
import urllib

#image moderation function to identify inappropriate images

# def moderate_image(photo, bucket):

#     client=boto3.client('rekognition')
#     #the function returns the inappropriate moderation labels related to the image
#     response = client.detect_moderation_labels(Image={'S3Object':{'Bucket':bucket,'Name':photo}})
    
#     return len(response['ModerationLabels'])

def detect_cars(photo, bucket):
    client=boto3.client('rekognition')
    response = client.detect_labels(Image={'S3Object':{'Bucket':bucket,'Name':photo}},MaxLabels=10)
    for label in response['Labels']:
        if label['Name']=="Car":
            return True
    return False

#lambda function triggred when file is uploaded to s3 bucket (imageverification bucket)

def lambda_handler (event, context):
    
    #get details of uploaded image :- name of bucket and name of file
    s3_client = boto3.client('s3')
    
    bucket_name = event ['Records'][0]['s3']['bucket']['name']
    key = event ['Records'][0]['s3']['object']['key']
    key= urllib.parse.unquote_plus(key, encoding='utf-8')
    
    
    response = s3_client.get_object (Bucket=bucket_name, Key=key)
    
    #calling image moderation function it returns the length of the moderation tags array
    
    # resp=moderate_image(key,bucket_name)
    resp=detect_cars(key,bucket_name)
    
    print(key)
    print(resp)
   
    
    s3 = boto3.resource('s3')
    #if value of resp i.e the length of the moderation lables array is greater than 0 then the image is 
    #classified as inappropriate and else it is classified as appropriate
    
    if resp==True:
        #copying the image file to the folder for inappropraite images
        copy_source = {
            'Bucket': bucket_name,
            'Key': key
        }
        dest='cars/'+key
        s3.meta.client.copy(copy_source,bucket_name , dest)
        
        #sending notification email to subscribed email ids of the topic using sns service
        
        #notification = "Unsafe Content image file has been uploaded to imageverification bucket with file name "+key
        notification="Car found in the photo with file name "+key+" in bucket "+bucket_name
        client = boto3.client('sns')
        response = client.publish (
              TargetArn = "arn:aws:sns:us-east-1:056999812124:car-detected",
              Message = json.dumps({'default': notification}),
              MessageStructure = 'json'
           )
        
    else:
        #copying the image file to the folder for appropraite images
        copy_source = {
            'Bucket': bucket_name,
            'Key': key
        }
        dest='nocars/'+key
        s3.meta.client.copy(copy_source,bucket_name , dest)
        
    #deleting the file form bucket after moving it to respective folders   
    s3_client.delete_object(Bucket=bucket_name, Key=key)